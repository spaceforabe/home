'use client'

import { useCallback, useState, useEffect } from 'react'
import {
  ComposableMap,
  Geographies,
  Geography,
  ZoomableGroup,
} from 'react-simple-maps'
import { useTrendStore } from '@/lib/trend-store'
import { countryHeatData } from '@/lib/mock-trends'

const geoUrl = 'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json'

// ISO 3166-1 numeric to alpha-3 mapping for common countries
const numericToAlpha3: Record<string, string> = {
  '840': 'USA', '076': 'BRA', '392': 'JPN', '826': 'GBR', '276': 'DEU',
  '250': 'FRA', '356': 'IND', '156': 'CHN', '036': 'AUS', '124': 'CAN',
  '484': 'MEX', '032': 'ARG', '724': 'ESP', '380': 'ITA', '643': 'RUS',
  '410': 'KOR', '710': 'ZAF', '566': 'NGA', '818': 'EGY', '682': 'SAU',
  '792': 'TUR', '360': 'IDN', '764': 'THA', '704': 'VNM', '608': 'PHL',
  '586': 'PAK', '050': 'BGD', '528': 'NLD', '056': 'BEL', '756': 'CHE',
  '752': 'SWE', '578': 'NOR', '208': 'DNK', '246': 'FIN', '616': 'POL',
  '804': 'UKR', '300': 'GRC', '620': 'PRT', '203': 'CZE', '040': 'AUT',
  '348': 'HUN', '372': 'IRL', '554': 'NZL', '702': 'SGP', '458': 'MYS',
  '170': 'COL', '152': 'CHL', '604': 'PER', '004': 'AFG', '008': 'ALB',
  '012': 'DZA', '020': 'AND', '024': 'AGO', '028': 'ATG', '031': 'AZE',
  '044': 'BHS', '048': 'BHR', '051': 'ARM', '052': 'BRB', '064': 'BTN',
  '068': 'BOL', '070': 'BIH', '072': 'BWA', '084': 'BLZ', '090': 'SLB',
  '096': 'BRN', '100': 'BGR', '104': 'MMR', '108': 'BDI', '112': 'BLR',
  '116': 'KHM', '120': 'CMR', '132': 'CPV', '140': 'CAF', '144': 'LKA',
  '148': 'TCD', '158': 'TWN', '178': 'COG', '180': 'COD', '188': 'CRI',
  '191': 'HRV', '192': 'CUB', '196': 'CYP', '204': 'BEN', '214': 'DOM',
  '218': 'ECU', '222': 'SLV', '226': 'GNQ', '231': 'ETH', '232': 'ERI',
  '233': 'EST', '242': 'FJI', '262': 'DJI', '266': 'GAB', '268': 'GEO',
  '270': 'GMB', '275': 'PSE', '288': 'GHA', '296': 'KIR', '308': 'GRD',
  '320': 'GTM', '324': 'GIN', '328': 'GUY', '332': 'HTI', '340': 'HND',
  '352': 'ISL', '364': 'IRN', '368': 'IRQ', '376': 'ISR', '384': 'CIV',
  '388': 'JAM', '398': 'KAZ', '400': 'JOR', '404': 'KEN', '408': 'PRK',
  '414': 'KWT', '417': 'KGZ', '418': 'LAO', '422': 'LBN', '426': 'LSO',
  '428': 'LVA', '430': 'LBR', '434': 'LBY', '440': 'LTU', '442': 'LUX',
  '450': 'MDG', '454': 'MWI', '466': 'MLI', '470': 'MLT', '478': 'MRT',
  '480': 'MUS', '496': 'MNG', '498': 'MDA', '499': 'MNE', '504': 'MAR',
  '508': 'MOZ', '512': 'OMN', '516': 'NAM', '520': 'NRU', '524': 'NPL',
  '548': 'VUT', '558': 'NIC', '562': 'NER', '585': 'PLW', '591': 'PAN',
  '598': 'PNG', '600': 'PRY', '634': 'QAT', '642': 'ROU', '646': 'RWA',
  '659': 'KNA', '662': 'LCA', '670': 'VCT', '678': 'STP', '680': 'PSE',
  '682': 'SAU', '686': 'SEN', '688': 'SRB', '690': 'SYC', '694': 'SLE',
  '702': 'SGP', '703': 'SVK', '705': 'SVN', '706': 'SOM', '716': 'ZWE',
  '728': 'SSD', '729': 'SDN', '740': 'SUR', '748': 'SWZ', '760': 'SYR',
  '762': 'TJK', '788': 'TUN', '795': 'TKM', '798': 'TUV', '800': 'UGA',
  '807': 'MKD', '834': 'TZA', '854': 'BFA', '858': 'URY', '860': 'UZB',
  '862': 'VEN', '887': 'YEM', '894': 'ZMB',
}

const getHeatColor = (heat: 'low' | 'medium' | 'high' | undefined) => {
  switch (heat) {
    case 'high':
      return '#00FFD1' // Neon teal
    case 'medium':
      return '#FFAA00' // Amber
    case 'low':
      return '#8B7355' // Muted amber/brown
    default:
      return '#1a2035' // Dark navy for no data
  }
}

const formatVolume = (volume: number): string => {
  if (volume >= 1_000_000) return `${(volume / 1_000_000).toFixed(1)}M`
  if (volume >= 1_000) return `${(volume / 1_000).toFixed(0)}K`
  return volume.toString()
}

interface TooltipData {
  name: string
  code: string
  heat: 'low' | 'medium' | 'high' | undefined
  volume: number
  x: number
  y: number
}

export function WorldMap() {
  const { navigateTo, currentLocation } = useTrendStore()
  const [tooltip, setTooltip] = useState<TooltipData | null>(null)
  const [position, setPosition] = useState({ coordinates: [0, 20] as [number, number], zoom: 1 })
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleCountryClick = useCallback(
    (geo: { properties: { name: string }; id: string }) => {
      const countryCode = numericToAlpha3[geo.id] || geo.id
      const countryName = geo.properties.name
      
      navigateTo({
        level: 'country',
        code: countryCode,
        name: countryName,
        parent: { level: 'global', code: 'GLOBAL', name: 'Global', emoji: '🌍' },
      })
    },
    [navigateTo]
  )

  const handleMouseEnter = useCallback(
    (geo: { properties: { name: string }; id: string }, event: React.MouseEvent) => {
      const countryCode = numericToAlpha3[geo.id] || geo.id
      const heatData = countryHeatData[countryCode]
      
      setTooltip({
        name: geo.properties.name,
        code: countryCode,
        heat: heatData?.heat,
        volume: heatData?.volume || 0,
        x: event.clientX,
        y: event.clientY,
      })
    },
    []
  )

  const handleMouseLeave = useCallback(() => {
    setTooltip(null)
  }, [])

  const handleMouseMove = useCallback((event: React.MouseEvent) => {
    if (tooltip) {
      setTooltip((prev) => prev ? { ...prev, x: event.clientX, y: event.clientY } : null)
    }
  }, [tooltip])

  if (!mounted) {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          <p className="font-mono text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="absolute inset-0 overflow-hidden" onMouseMove={handleMouseMove}>
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{
          scale: 140,
          center: [0, 20],
        }}
        className="h-full w-full"
        style={{ backgroundColor: 'transparent' }}
      >
        <ZoomableGroup
          center={position.coordinates}
          zoom={position.zoom}
          onMoveEnd={({ coordinates, zoom }) => setPosition({ coordinates, zoom })}
          minZoom={1}
          maxZoom={8}
        >
          <Geographies geography={geoUrl}>
            {({ geographies }) =>
              geographies.map((geo) => {
                const countryCode = numericToAlpha3[geo.id] || geo.id
                const heatData = countryHeatData[countryCode]
                const fillColor = getHeatColor(heatData?.heat)
                const isActive = currentLocation.code === countryCode

                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    onClick={() => handleCountryClick(geo)}
                    onMouseEnter={(e) => handleMouseEnter(geo, e)}
                    onMouseLeave={handleMouseLeave}
                    style={{
                      default: {
                        fill: fillColor,
                        stroke: '#0d1424',
                        strokeWidth: 0.5,
                        outline: 'none',
                        transition: 'all 0.3s ease',
                        cursor: 'pointer',
                        filter: heatData?.heat === 'high' ? 'drop-shadow(0 0 8px rgba(0, 255, 209, 0.4))' : 'none',
                      },
                      hover: {
                        fill: '#00FFD1',
                        stroke: '#00FFD1',
                        strokeWidth: 1,
                        outline: 'none',
                        cursor: 'pointer',
                        filter: 'drop-shadow(0 0 12px rgba(0, 255, 209, 0.6))',
                      },
                      pressed: {
                        fill: '#00E5BC',
                        stroke: '#00FFD1',
                        strokeWidth: 1.5,
                        outline: 'none',
                      },
                    }}
                  />
                )
              })
            }
          </Geographies>
        </ZoomableGroup>
      </ComposableMap>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="pointer-events-none fixed z-50 rounded-lg border border-border/50 bg-card/95 px-4 py-3 shadow-2xl backdrop-blur-sm"
          style={{
            left: tooltip.x + 16,
            top: tooltip.y - 16,
            transform: 'translateY(-100%)',
          }}
        >
          <div className="flex items-center gap-2">
            <span className="text-lg">{tooltip.name}</span>
            {tooltip.heat && (
              <span
                className="inline-block h-2 w-2 rounded-full"
                style={{ backgroundColor: getHeatColor(tooltip.heat) }}
              />
            )}
          </div>
          {tooltip.volume > 0 && (
            <div className="mt-1 font-mono text-sm text-muted-foreground">
              {formatVolume(tooltip.volume)} mentions
            </div>
          )}
          <div className="mt-2 text-xs text-primary">Click to explore trends</div>
        </div>
      )}

      {/* Zoom Controls */}
      <div className="absolute bottom-6 right-6 flex flex-col gap-2">
        <button
          onClick={() => setPosition((p) => ({ ...p, zoom: Math.min(p.zoom * 1.5, 8) }))}
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-card/80 font-mono text-lg text-foreground backdrop-blur-sm transition-colors hover:bg-secondary hover:text-primary"
        >
          +
        </button>
        <button
          onClick={() => setPosition((p) => ({ ...p, zoom: Math.max(p.zoom / 1.5, 1) }))}
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-card/80 font-mono text-lg text-foreground backdrop-blur-sm transition-colors hover:bg-secondary hover:text-primary"
        >
          -
        </button>
        <button
          onClick={() => setPosition({ coordinates: [0, 20], zoom: 1 })}
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-card/80 text-sm text-muted-foreground backdrop-blur-sm transition-colors hover:bg-secondary hover:text-primary"
          title="Reset view"
        >
          <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
      </div>
    </div>
  )
}
