import useSWR from 'swr'
import { useTrendStore } from '@/lib/trend-store'

const fetcher = (url: string) => fetch(url).then(res => res.json())

export function useGlobalTrends() {
  const { filters, sources } = useTrendStore()
  const enabledSources = sources.filter(s => s.enabled).map(s => s.id)
  
  const url = `/api/trends?level=global&window=${filters.timeWindow}&sources=${enabledSources.join(',')}`
  
  return useSWR(url, fetcher, {
    refreshInterval: 300000, // Refresh every 5 minutes
    revalidateOnFocus: true,
  })
}

export function useCountryTrends(countryCode: string | null) {
  const { filters, sources } = useTrendStore()
  const enabledSources = sources.filter(s => s.enabled).map(s => s.id)
  
  const url = countryCode 
    ? `/api/trends?level=country&code=${countryCode}&window=${filters.timeWindow}&sources=${enabledSources.join(',')}`
    : null
  
  return useSWR(url, fetcher, {
    refreshInterval: 300000,
    revalidateOnFocus: true,
  })
}

export function useTopicDetails(topicId: string | null, geo?: string) {
  const { filters } = useTrendStore()
  
  const url = topicId
    ? `/api/topic/${topicId}?geo=${geo || 'GLOBAL'}&window=${filters.timeWindow}`
    : null
  
  return useSWR(url, fetcher, {
    refreshInterval: 60000, // More frequent updates for topic details
  })
}
