import type { TrendTopic, TrendData, GeoLocation } from './trend-store'

const generateSparkline = (trend: 'rising' | 'falling' | 'stable'): number[] => {
  const base = Math.random() * 50 + 25
  return Array.from({ length: 12 }, (_, i) => {
    const variance = Math.random() * 20 - 10
    if (trend === 'rising') return base + i * 3 + variance
    if (trend === 'falling') return base + (12 - i) * 3 + variance
    return base + variance
  })
}

export const formatVolume = (volume: number): string => {
  if (volume >= 1_000_000) return `${(volume / 1_000_000).toFixed(1)}M`
  if (volume >= 1_000) return `${(volume / 1_000).toFixed(0)}K`
  return volume.toString()
}

const sampleTopicsByCountry: Record<string, { name: string; baseVolume: number }[]> = {
  USA: [
    { name: 'AI Regulation Debate', baseVolume: 4200000 },
    { name: 'Super Bowl LXII', baseVolume: 3100000 },
    { name: 'Tech Layoffs Wave', baseVolume: 2800000 },
    { name: 'Climate Action Summit', baseVolume: 1900000 },
    { name: 'Housing Market Shift', baseVolume: 1400000 },
  ],
  BRA: [
    { name: 'Carnival 2026', baseVolume: 5600000 },
    { name: 'Amazon Conservation', baseVolume: 2400000 },
    { name: 'Serie A Finals', baseVolume: 1800000 },
    { name: 'Economic Recovery', baseVolume: 1200000 },
    { name: 'Tech Startups Boom', baseVolume: 890000 },
  ],
  JPN: [
    { name: 'Cherry Blossom Season', baseVolume: 2400000 },
    { name: 'Bank of Japan Rate Decision', baseVolume: 890000 },
    { name: 'Earthquake Warning System', baseVolume: 340000 },
    { name: 'Anime Industry Record', baseVolume: 1200000 },
    { name: 'Robot Workforce', baseVolume: 670000 },
  ],
  GBR: [
    { name: 'Premier League Drama', baseVolume: 3100000 },
    { name: 'Royal Family News', baseVolume: 2200000 },
    { name: 'NHS Reform Bill', baseVolume: 1500000 },
    { name: 'Brexit Impact Study', baseVolume: 980000 },
    { name: 'London Housing Crisis', baseVolume: 720000 },
  ],
  DEU: [
    { name: 'Energiewende Progress', baseVolume: 1800000 },
    { name: 'Bundesliga Weekend', baseVolume: 2100000 },
    { name: 'Auto Industry EV Pivot', baseVolume: 1400000 },
    { name: 'Immigration Policy', baseVolume: 1100000 },
    { name: 'Berlin Tech Week', baseVolume: 560000 },
  ],
  FRA: [
    { name: 'Paris Fashion Week', baseVolume: 2900000 },
    { name: 'Pension Reform Protests', baseVolume: 1700000 },
    { name: 'Ligue 1 Title Race', baseVolume: 1200000 },
    { name: 'Wine Harvest Report', baseVolume: 540000 },
    { name: 'Nuclear Energy Expansion', baseVolume: 890000 },
  ],
  IND: [
    { name: 'Cricket World Cup', baseVolume: 8200000 },
    { name: 'Monsoon Season Update', baseVolume: 3400000 },
    { name: 'Tech Hub Expansion', baseVolume: 2100000 },
    { name: 'Bollywood Blockbuster', baseVolume: 4500000 },
    { name: 'Space Program Success', baseVolume: 1800000 },
  ],
  CHN: [
    { name: 'Lunar New Year Prep', baseVolume: 12000000 },
    { name: 'Tech Sector Regulations', baseVolume: 5400000 },
    { name: 'EV Export Surge', baseVolume: 3200000 },
    { name: 'Property Market News', baseVolume: 2800000 },
    { name: 'AI Chip Development', baseVolume: 1900000 },
  ],
  AUS: [
    { name: 'Australian Open Tennis', baseVolume: 1600000 },
    { name: 'Bushfire Season Alert', baseVolume: 980000 },
    { name: 'Great Barrier Reef', baseVolume: 720000 },
    { name: 'Mining Industry News', baseVolume: 540000 },
    { name: 'Housing Affordability', baseVolume: 890000 },
  ],
  CAN: [
    { name: 'Hockey Playoffs', baseVolume: 1400000 },
    { name: 'Housing Market Crash', baseVolume: 1100000 },
    { name: 'Immigration Surge', baseVolume: 870000 },
    { name: 'Oil Sands Debate', baseVolume: 620000 },
    { name: 'Aurora Borealis Event', baseVolume: 450000 },
  ],
}

const defaultTopics: { name: string; baseVolume: number }[] = [
  { name: 'Global Climate Summit', baseVolume: 1200000 },
  { name: 'Economic Outlook', baseVolume: 890000 },
  { name: 'Technology Trends', baseVolume: 670000 },
  { name: 'Local Elections', baseVolume: 450000 },
  { name: 'Sports Championship', baseVolume: 340000 },
]

const sources = ['Twitter', 'Reddit', 'YouTube', 'TikTok', 'Google Trends', 'News']

const generateTopic = (base: { name: string; baseVolume: number }, index: number): TrendTopic => {
  const velocity = index === 0 ? 'rising' : Math.random() > 0.6 ? 'falling' : Math.random() > 0.3 ? 'rising' : 'stable'
  const velocityPercent = velocity === 'rising' 
    ? Math.floor(Math.random() * 400 + 50) 
    : velocity === 'falling' 
    ? -Math.floor(Math.random() * 50 + 10)
    : Math.floor(Math.random() * 20 - 10)
  
  const positive = Math.random() * 60 + 20
  const negative = Math.random() * (100 - positive - 10)
  const neutral = 100 - positive - negative

  const numSources = Math.floor(Math.random() * 3) + 2
  const topicSources = sources.sort(() => Math.random() - 0.5).slice(0, numSources)

  return {
    id: `topic-${base.name.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}`,
    name: base.name,
    volume: base.baseVolume + Math.floor(Math.random() * 500000 - 250000),
    volumeFormatted: formatVolume(base.baseVolume),
    sentiment: {
      positive: Math.round(positive),
      neutral: Math.round(neutral),
      negative: Math.round(negative),
    },
    sources: topicSources,
    velocity,
    velocityPercent,
    sparklineData: generateSparkline(velocity),
    keywords: ['trending', 'viral', 'news', 'update', 'breaking'].sort(() => Math.random() - 0.5).slice(0, 3),
    samplePosts: [
      {
        content: `This is a sample post about ${base.name}. The discussion is really heating up!`,
        source: topicSources[0],
        timestamp: '2 hours ago',
        sentiment: positive > 50 ? 'positive' : positive > 30 ? 'neutral' : 'negative',
      },
      {
        content: `Another perspective on ${base.name} - what do you all think about this?`,
        source: topicSources[1] || topicSources[0],
        timestamp: '4 hours ago',
        sentiment: 'neutral',
      },
    ],
  }
}

export const generateCountryTrends = (countryCode: string, countryName: string): TrendData => {
  const topicsBase = sampleTopicsByCountry[countryCode] || defaultTopics
  const topics = topicsBase.map((base, i) => generateTopic(base, i))
  const totalVolume = topics.reduce((sum, t) => sum + t.volume, 0)
  
  const location: GeoLocation = {
    level: 'country',
    code: countryCode,
    name: countryName,
    emoji: getCountryEmoji(countryCode),
    parent: { level: 'global', code: 'GLOBAL', name: 'Global', emoji: '🌍' },
  }

  return {
    location,
    topics,
    totalVolume,
    lastUpdated: new Date(),
    heatLevel: totalVolume > 5000000 ? 'high' : totalVolume > 2000000 ? 'medium' : 'low',
  }
}

export const getCountryEmoji = (code: string): string => {
  const emojiMap: Record<string, string> = {
    USA: '🇺🇸', BRA: '🇧🇷', JPN: '🇯🇵', GBR: '🇬🇧', DEU: '🇩🇪', FRA: '🇫🇷',
    IND: '🇮🇳', CHN: '🇨🇳', AUS: '🇦🇺', CAN: '🇨🇦', MEX: '🇲🇽', ARG: '🇦🇷',
    ESP: '🇪🇸', ITA: '🇮🇹', RUS: '🇷🇺', KOR: '🇰🇷', ZAF: '🇿🇦', NGA: '🇳🇬',
    EGY: '🇪🇬', SAU: '🇸🇦', TUR: '🇹🇷', IDN: '🇮🇩', THA: '🇹🇭', VNM: '🇻🇳',
    PHL: '🇵🇭', PAK: '🇵🇰', BGD: '🇧🇩', NLD: '🇳🇱', BEL: '🇧🇪', CHE: '🇨🇭',
    SWE: '🇸🇪', NOR: '🇳🇴', DNK: '🇩🇰', FIN: '🇫🇮', POL: '🇵🇱', UKR: '🇺🇦',
    GRC: '🇬🇷', PRT: '🇵🇹', CZE: '🇨🇿', AUT: '🇦🇹', HUN: '🇭🇺', IRL: '🇮🇪',
    NZL: '🇳🇿', SGP: '🇸🇬', MYS: '🇲🇾', COL: '🇨🇴', CHL: '🇨🇱', PER: '🇵🇪',
  }
  return emojiMap[code] || '🏳️'
}

export const countryHeatData: Record<string, { heat: 'low' | 'medium' | 'high'; volume: number }> = {
  USA: { heat: 'high', volume: 15400000 },
  CHN: { heat: 'high', volume: 25600000 },
  IND: { heat: 'high', volume: 20000000 },
  BRA: { heat: 'high', volume: 12500000 },
  JPN: { heat: 'medium', volume: 5500000 },
  GBR: { heat: 'medium', volume: 8500000 },
  DEU: { heat: 'medium', volume: 7000000 },
  FRA: { heat: 'medium', volume: 7200000 },
  CAN: { heat: 'medium', volume: 4500000 },
  AUS: { heat: 'medium', volume: 4700000 },
  RUS: { heat: 'medium', volume: 6200000 },
  KOR: { heat: 'medium', volume: 4800000 },
  MEX: { heat: 'low', volume: 3200000 },
  ITA: { heat: 'low', volume: 3800000 },
  ESP: { heat: 'low', volume: 3400000 },
  IDN: { heat: 'medium', volume: 5100000 },
  TUR: { heat: 'low', volume: 2900000 },
  SAU: { heat: 'low', volume: 1800000 },
  ARG: { heat: 'low', volume: 2400000 },
  ZAF: { heat: 'low', volume: 1600000 },
  NGA: { heat: 'medium', volume: 4200000 },
  EGY: { heat: 'low', volume: 1900000 },
  THA: { heat: 'low', volume: 2100000 },
  VNM: { heat: 'low', volume: 1700000 },
  PHL: { heat: 'low', volume: 2300000 },
  PAK: { heat: 'low', volume: 2800000 },
  NLD: { heat: 'low', volume: 1200000 },
  SWE: { heat: 'low', volume: 800000 },
  POL: { heat: 'low', volume: 1500000 },
  UKR: { heat: 'low', volume: 1100000 },
}

export const globalTopTrends: TrendTopic[] = [
  generateTopic({ name: 'AI Revolution 2026', baseVolume: 45000000 }, 0),
  generateTopic({ name: 'Climate Emergency', baseVolume: 32000000 }, 1),
  generateTopic({ name: 'Global Elections', baseVolume: 28000000 }, 2),
  generateTopic({ name: 'Cryptocurrency Surge', baseVolume: 21000000 }, 3),
  generateTopic({ name: 'Space Exploration', baseVolume: 15000000 }, 4),
]
