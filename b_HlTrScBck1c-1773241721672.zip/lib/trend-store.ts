import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type GeographyLevel = 'global' | 'country' | 'region' | 'city'

export interface TrendTopic {
  id: string
  name: string
  volume: number
  volumeFormatted: string
  sentiment: {
    positive: number
    neutral: number
    negative: number
  }
  sources: string[]
  velocity: 'rising' | 'falling' | 'stable'
  velocityPercent: number
  sparklineData: number[]
  samplePosts?: {
    content: string
    source: string
    timestamp: string
    sentiment: 'positive' | 'neutral' | 'negative'
  }[]
  keywords?: string[]
}

export interface GeoLocation {
  level: GeographyLevel
  code: string
  name: string
  emoji?: string
  parent?: GeoLocation
}

export interface TrendData {
  location: GeoLocation
  topics: TrendTopic[]
  totalVolume: number
  lastUpdated: Date
  heatLevel: 'low' | 'medium' | 'high'
}

export interface SourceConfig {
  id: string
  name: string
  category: 'social' | 'news'
  enabled: boolean
  icon: string
}

export interface FilterConfig {
  language: string
  timeWindow: '1h' | '6h' | '24h' | '7d'
  contentType: 'all' | 'text' | 'video' | 'images'
}

interface TrendStore {
  // Navigation state
  currentLocation: GeoLocation
  breadcrumbs: GeoLocation[]
  
  // UI state
  selectedTopic: TrendTopic | null
  isTrendPanelOpen: boolean
  isSourceSelectorOpen: boolean
  isTopicViewOpen: boolean
  
  // Data
  trendData: Map<string, TrendData>
  
  // Sources & Filters
  sources: SourceConfig[]
  filters: FilterConfig
  
  // Actions
  navigateTo: (location: GeoLocation) => void
  navigateBack: () => void
  navigateToGlobal: () => void
  setSelectedTopic: (topic: TrendTopic | null) => void
  setTrendPanelOpen: (open: boolean) => void
  setSourceSelectorOpen: (open: boolean) => void
  setTopicViewOpen: (open: boolean) => void
  toggleSource: (sourceId: string) => void
  setFilter: <K extends keyof FilterConfig>(key: K, value: FilterConfig[K]) => void
  setTrendData: (locationCode: string, data: TrendData) => void
}

const defaultSources: SourceConfig[] = [
  { id: 'twitter', name: 'X / Twitter', category: 'social', enabled: true, icon: 'twitter' },
  { id: 'reddit', name: 'Reddit', category: 'social', enabled: true, icon: 'reddit' },
  { id: 'tiktok', name: 'TikTok', category: 'social', enabled: true, icon: 'tiktok' },
  { id: 'youtube', name: 'YouTube', category: 'social', enabled: true, icon: 'youtube' },
  { id: 'instagram', name: 'Instagram', category: 'social', enabled: false, icon: 'instagram' },
  { id: 'bluesky', name: 'Bluesky', category: 'social', enabled: false, icon: 'bluesky' },
  { id: 'mastodon', name: 'Mastodon', category: 'social', enabled: false, icon: 'mastodon' },
  { id: 'google-trends', name: 'Google Trends', category: 'news', enabled: true, icon: 'google' },
  { id: 'rss-news', name: 'RSS/News Feeds', category: 'news', enabled: true, icon: 'rss' },
  { id: 'reddit-news', name: 'Reddit News', category: 'news', enabled: false, icon: 'reddit' },
]

const globalLocation: GeoLocation = {
  level: 'global',
  code: 'GLOBAL',
  name: 'Global',
  emoji: '🌍',
}

export const useTrendStore = create<TrendStore>()(
  persist(
    (set) => ({
      currentLocation: globalLocation,
      breadcrumbs: [globalLocation],
      selectedTopic: null,
      isTrendPanelOpen: false,
      isSourceSelectorOpen: false,
      isTopicViewOpen: false,
      trendData: new Map(),
      sources: defaultSources,
      filters: {
        language: 'all',
        timeWindow: '24h',
        contentType: 'all',
      },

      navigateTo: (location) =>
        set((state) => ({
          currentLocation: location,
          breadcrumbs: [...state.breadcrumbs, location],
          isTrendPanelOpen: true,
          selectedTopic: null,
        })),

      navigateBack: () =>
        set((state) => {
          if (state.breadcrumbs.length <= 1) return state
          const newBreadcrumbs = state.breadcrumbs.slice(0, -1)
          return {
            currentLocation: newBreadcrumbs[newBreadcrumbs.length - 1],
            breadcrumbs: newBreadcrumbs,
            selectedTopic: null,
          }
        }),

      navigateToGlobal: () =>
        set({
          currentLocation: globalLocation,
          breadcrumbs: [globalLocation],
          isTrendPanelOpen: false,
          selectedTopic: null,
        }),

      setSelectedTopic: (topic) => set({ selectedTopic: topic }),
      setTrendPanelOpen: (open) => set({ isTrendPanelOpen: open }),
      setSourceSelectorOpen: (open) => set({ isSourceSelectorOpen: open }),
      setTopicViewOpen: (open) => set({ isTopicViewOpen: open }),

      toggleSource: (sourceId) =>
        set((state) => ({
          sources: state.sources.map((s) =>
            s.id === sourceId ? { ...s, enabled: !s.enabled } : s
          ),
        })),

      setFilter: (key, value) =>
        set((state) => ({
          filters: { ...state.filters, [key]: value },
        })),

      setTrendData: (locationCode, data) =>
        set((state) => {
          const newMap = new Map(state.trendData)
          newMap.set(locationCode, data)
          return { trendData: newMap }
        }),
    }),
    {
      name: 'trendpulse-store',
      partialize: (state) => ({
        sources: state.sources,
        filters: state.filters,
      }),
    }
  )
)
